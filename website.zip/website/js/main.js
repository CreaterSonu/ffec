// Shared across all pages: mobile menu
(function () {
    const toggleBtn = document.getElementById('mobileToggleBtn');
    const navWrapper = document.getElementById('navWrapper');
    const overlayDiv = document.getElementById('mobileOverlay');
    function closeMenu() { navWrapper.classList.remove('active'); overlayDiv.classList.remove('active'); if(toggleBtn) toggleBtn.innerHTML = '<i class="fas fa-bars"></i>'; }
    function openMenu() { navWrapper.classList.add('active'); overlayDiv.classList.add('active'); toggleBtn.innerHTML = '<i class="fas fa-times"></i>'; }
    if(toggleBtn) toggleBtn.addEventListener('click', (e) => { e.stopPropagation(); navWrapper.classList.contains('active') ? closeMenu() : openMenu(); });
    overlayDiv.addEventListener('click', closeMenu);
    window.addEventListener('resize', () => { if(window.innerWidth > 880 && navWrapper.classList.contains('active')) closeMenu(); });
})();
