if (window.AOS) AOS.init({ duration: 800, once: true });

// Counters
const counters = document.querySelectorAll('.counter');
let counted = false;
const startCounting = () => {
    counters.forEach(counter => {
        const updateCount = () => {
            const target = parseInt(counter.getAttribute('data-target'));
            const current = parseInt(counter.innerText);
            const increment = Math.ceil(target / 20);
            if (current < target) {
                counter.innerText = current + increment;
                setTimeout(updateCount, 25);
            } else counter.innerText = target;
        };
        updateCount();
    });
};
const statsSection = document.querySelector('.stats-banner');
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => { if (entry.isIntersecting && !counted) { counted = true; startCounting(); } });
}, { threshold: 0.4 });
if(statsSection) observer.observe(statsSection);

// FAQ Accordion
const faqItems = document.querySelectorAll('.faq-item');
faqItems.forEach(item => {
    const question = item.querySelector('.faq-question');
    question.addEventListener('click', () => {
        const isActive = item.classList.contains('active');
        faqItems.forEach(i => i.classList.remove('active'));
        if (!isActive) item.classList.add('active');
    });
});
if(faqItems.length) faqItems[0].classList.add('active');

// Button Alerts
const showContactMsg = () => alert("📞 Contact marketplace experts: +91 98765 43210 | email: onboard@yourcompany.com");
document.getElementById('getStartedBtn')?.addEventListener('click', (e) => { e.preventDefault(); showContactMsg(); });
document.getElementById('contactHeroBtn')?.addEventListener('click', (e) => { e.preventDefault(); showContactMsg(); });
document.getElementById('quoteBtn')?.addEventListener('click', (e) => { e.preventDefault(); alert("💬 Get a custom quote for multi-marketplace management + onboarding."); });
document.querySelectorAll('.portfolio-item').forEach(p => { p.addEventListener('click', () => { alert("📸 View full marketplace success portfolio. Contact for case studies."); }); });

// ---------- Brands carousel (right -> left, infinite) ----------
// HTML me brands sirf ek baar likhe hote hain; yahan se copies bana kar loop smooth banaya jata hai.
(function () {
    const marquee = document.getElementById('brandsMarquee');
    const track = document.getElementById('brandsTrack');
    if (!marquee || !track) return;

    const originals = Array.from(track.children);
    if (!originals.length) return;

    const SPEED = 60; // pixels per second (chhota number = dheere)

    function cloneSet() {
        return originals.map((el) => {
            const c = el.cloneNode(true);
            c.setAttribute('data-clone', '1');
            c.setAttribute('aria-hidden', 'true');
            c.querySelectorAll('img').forEach((img) => { img.alt = ''; });
            return c;
        });
    }

    function build() {
        track.classList.remove('is-ready');
        track.querySelectorAll('[data-clone]').forEach((el) => el.remove());

        const setWidth = track.offsetWidth;          // ek set ki width
        if (!setWidth) return;
        const repeats = Math.max(1, Math.ceil(marquee.offsetWidth / setWidth));

        // pehla half = repeats x set, doosra half = uski exact copy (translateX(-50%) loop ke liye)
        for (let i = 0; i < repeats * 2 - 1; i++) cloneSet().forEach((c) => track.appendChild(c));

        track.style.animationDuration = ((setWidth * repeats) / SPEED) + 's';
        track.classList.add('is-ready');
    }

    let timer;
    window.addEventListener('load', build);
    window.addEventListener('resize', () => { clearTimeout(timer); timer = setTimeout(build, 200); });
})();
