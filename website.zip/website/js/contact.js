if (window.AOS) AOS.init({ duration: 800, once: true });

document.getElementById('quoteBtn')?.addEventListener('click', (e) => { e.preventDefault(); alert("📧 Get a Quote: Share your requirements with our team at contact@yourcompany.com."); });

// =====================================================================
//  GOOGLE SHEET CONNECTION
//  Google Apps Script ko "Web app" ke roop me deploy karne ke baad jo URL
//  mile (https://script.google.com/macros/s/.../exec), use neeche paste karo.
//  Poora setup: google-sheet-setup/SETUP.md
// =====================================================================
const SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbzUgHUPZU7CrciD6EnXWLe2TON7FcyPotig9jTzGRQM_7Niotq8xYIHotil4OzCdd-T/exec';

const contactForm = document.getElementById('contactForm');
const submitBtn = document.getElementById('submitBtn');
const formStatus = document.getElementById('formStatus');
const submitBtnHTML = submitBtn.innerHTML;

function showStatus(type, text) {
    formStatus.textContent = text;
    formStatus.className = 'form-status show ' + type;
}

function clearStatus() {
    formStatus.textContent = '';
    formStatus.className = 'form-status';
}

contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearStatus();

    const fullName = document.getElementById('fullName').value.trim();
    const email = document.getElementById('email').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const message = document.getElementById('message').value.trim();

    if (!fullName || !email || !phone || !message) { showStatus('error', '❌ Please fill in all required fields (*)'); return; }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) { showStatus('error', '❌ Please enter a valid email address'); return; }
    if (phone.replace(/\D/g, '').length < 10) { showStatus('error', '❌ Please enter a valid phone number'); return; }
    if (message.length > 3000) { showStatus('error', '❌ Message is too long (max 3000 characters)'); return; }

    // Honeypot: real users never see/fill this field. Bots do -> silently pretend success.
    if (contactForm.elements['website'].value) { contactForm.reset(); showStatus('success', '✅ Thank you! We will contact you soon.'); return; }

    if (!SCRIPT_URL || SCRIPT_URL.indexOf('PASTE_YOUR') !== -1) {
        console.error('contact.js: SCRIPT_URL set nahi hai. google-sheet-setup/SETUP.md follow karo.');
        showStatus('error', '⚠️ Form is not connected yet. Please call us on +91 72580 64388.');
        return;
    }

    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';

    const data = new FormData(contactForm);
    data.append('page', window.location.href);

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 20000);

    try {
        const response = await fetch(SCRIPT_URL, { method: 'POST', body: data, signal: controller.signal });
        const result = await response.json();
        if (result.result !== 'success') throw new Error(result.error || 'Unknown error');

        contactForm.reset();
        showStatus('success', `✅ Thank you ${fullName} for contacting FastForward! Our team will get back to you within 24 hours. For urgent queries, call +91 72580 64388.`);
    } catch (err) {
        console.error('Form submit failed:', err);
        showStatus('error', '❌ Sorry, something went wrong. Please try again or call us on +91 72580 64388.');
    } finally {
        clearTimeout(timer);
        submitBtn.disabled = false;
        submitBtn.innerHTML = submitBtnHTML;
    }
});
