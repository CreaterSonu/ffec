if (window.AOS) AOS.init({ duration: 800, once: true, offset: 100 });

// Quote button demo
document.getElementById('quoteBtn')?.addEventListener('click', (e) => { e.preventDefault(); alert("📧 Request a quote: Please share your requirements with our team at info@yourcompany.com or call +91 98765 43210."); });

// Helper: All sensitive values and editable content are clearly marked with IDs. 
// You can directly update via JavaScript or edit the HTML elements.
console.log("About Us page loaded — You can now replace all text, images, names, founding year via the IDs or directly in HTML.");
// Example: If you want to set values programmatically:
// document.getElementById('foundingYear').innerText = "2020";
// document.getElementById('founderName').innerText = "Rahul Sharma";
// etc. But all placeholders are ready for your data.
