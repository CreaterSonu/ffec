if (window.AOS) AOS.init({ duration: 800, once: true });
document.getElementById('quoteBtn')?.addEventListener('click', (e) => { e.preventDefault(); alert("📧 Request a quote: Share your requirements at info@yourcompany.com or call +91 98765 43210."); });
