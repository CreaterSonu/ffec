if (window.AOS) AOS.init({ duration: 800, once: true });

const portfolioData = [
    { id: 1, name: "Fashion E-commerce Platform", category: "websites", industry: "Retail / Fashion", description: "Full-featured online store with seamless checkout and mobile-first design.", img: "https://placehold.co/600x400/1e3a5f/white?text=Ecommerce+Website" },
    { id: 2, name: "Corporate Tech Solutions", category: "websites", industry: "IT Services", description: "Modern corporate website with service showcase and lead generation forms.", img: "https://placehold.co/600x400/2b5a7a/white?text=Corporate+Website" },
    { id: 3, name: "Electronics Brand A+ Content", category: "amazon", industry: "Consumer Electronics", description: "Enhanced brand content with comparison charts and premium images.", img: "https://placehold.co/600x400/0f2c44/white?text=Amazon+A%2B+Electronics" },
    { id: 4, name: "Home Decor A+ Listing", category: "amazon", industry: "Home & Kitchen", description: "Rich A+ content with lifestyle imagery and increased conversion rate.", img: "https://placehold.co/600x400/1e3a5f/white?text=Home+Decor+A%2B" },
    { id: 5, name: "Fitness Equipment Brand Store", category: "brandstore", industry: "Fitness", description: "Amazon Brand Store with video banners and product collections.", img: "https://placehold.co/600x400/1e3c72/white?text=Brand+Store+Fitness" },
    { id: 6, name: "Organic Foods Brand Store", category: "brandstore", industry: "Food & Beverage", description: "Immersive brand store with storytelling and bestseller grid.", img: "https://placehold.co/600x400/0f2c44/white?text=Organic+Brand+Store" },
    { id: 7, name: "Tech Startup Logo Suite", category: "logo", industry: "Technology", description: "Modern logo with alternate versions and brand guidelines.", img: "https://placehold.co/600x400/2b5a7a/white?text=Tech+Startup+Logo" },
    { id: 8, name: "Organic Farm Brand Identity", category: "logo", industry: "Agriculture", description: "Earthy and minimal logo design with nature-inspired elements.", img: "https://placehold.co/600x400/1e3c72/white?text=Organic+Farm+Logo" },
    { id: 9, name: "Amazon Sponsored Ads Creatives", category: "ads", industry: "E-commerce", description: "High-CTR ad creatives for Amazon sponsored products.", img: "https://placehold.co/600x400/1e3a5f/white?text=Amazon+Ads" },
    { id: 10, name: "Social Media Carousel Ads", category: "ads", industry: "Digital Marketing", description: "Engaging carousel ads for Instagram and Facebook.", img: "https://placehold.co/600x400/2b5a7a/white?text=Social+Media+Ads" }
];

function getCategoryLabel(cat) {
    const labels = { websites: '🌐 Website', amazon: '📦 Amazon A+', brandstore: '🏬 Brand Store', logo: '🎨 Logo', ads: '📢 Ad Creative' };
    return labels[cat] || cat;
}

function renderPortfolio(category) {
    const grid = document.getElementById('portfolioGrid');
    const filtered = category === 'all' ? portfolioData : portfolioData.filter(item => item.category === category);
    if (filtered.length === 0) { grid.innerHTML = `<div class="no-results"><i class="fas fa-folder-open icon-empty-state"></i><h3>No projects found</h3><p>Try another category</p></div>`; return; }
    grid.innerHTML = filtered.map(project => `<div class="portfolio-card"><div class="card-img-wrapper"><img src="${project.img}" alt="${project.name}" class="portfolio-img"><span class="category-badge">${getCategoryLabel(project.category)}</span></div><div class="portfolio-info"><span class="client-industry"><i class="fas fa-industry"></i> ${project.industry}</span><h3>${project.name}</h3><p>${project.description}</p></div></div>`).join('');
}

const categoryBtns = document.querySelectorAll('.category-btn');
categoryBtns.forEach(btn => { btn.addEventListener('click', () => { const category = btn.getAttribute('data-category'); categoryBtns.forEach(b => b.classList.remove('active')); btn.classList.add('active'); renderPortfolio(category); document.getElementById('portfolioGrid').scrollIntoView({ behavior: 'smooth', block: 'start' }); }); });
renderPortfolio('all');

document.getElementById('quoteBtn')?.addEventListener('click', (e) => { e.preventDefault(); alert("📧 Get a Quote: Share your project requirements with us."); });
document.querySelectorAll('.btn-light').forEach(btn => { btn.addEventListener('click', (e) => { e.preventDefault(); alert("✨ Let's discuss your next project! Contact our team at +91 98765 43210."); }); });
