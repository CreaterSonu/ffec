if (window.AOS) AOS.init({ duration: 800, once: true });

const blogPosts = [
    { id: 1, title: "How To Grow Amazon Sales in 2025", category: "amazon", date: "May 15, 2025", excerpt: "Discover proven strategies to boost your Amazon sales, optimize PPC campaigns, and improve organic ranking.", image: "https://placehold.co/600x400/1e3a5f/white?text=Amazon+Sales+Growth", readTime: "6 min read" },
    { id: 2, title: "Best Website Design Trends for Modern Brands", category: "webdesign", date: "May 10, 2025", excerpt: "From dark mode to micro-interactions — explore the top web design trends that enhance user experience.", image: "https://placehold.co/600x400/2b5a7a/white?text=Web+Design+Trends", readTime: "5 min read" },
    { id: 3, title: "SEO Tips For Business Growth in 2025", category: "seo", date: "May 5, 2025", excerpt: "Actionable SEO strategies to improve search rankings, drive organic traffic, and increase conversions.", image: "https://placehold.co/600x400/1e3c72/white?text=SEO+Tips", readTime: "7 min read" },
    { id: 4, title: "AI Tools For Marketing: Boost Productivity", category: "ai", date: "April 28, 2025", excerpt: "Explore the best AI tools for content creation, ad optimization, and marketing automation.", image: "https://placehold.co/600x400/0f2c44/white?text=AI+Marketing+Tools", readTime: "8 min read" },
    { id: 5, title: "Amazon PPC Optimization: Reduce ACoS", category: "amazon", date: "April 20, 2025", excerpt: "Learn how to optimize your Amazon sponsored ads, lower ACoS, and maximize ROI.", image: "https://placehold.co/600x400/1e3a5f/white?text=Amazon+PPC", readTime: "6 min read" },
    { id: 6, title: "Mobile-First Web Design: Why It Matters", category: "webdesign", date: "April 15, 2025", excerpt: "Mobile-first indexing is crucial. Learn best practices for responsive design.", image: "https://placehold.co/600x400/2b5a7a/white?text=Mobile+First+Design", readTime: "5 min read" },
    { id: 7, title: "Local SEO: Rank Your Business on Google Maps", category: "seo", date: "April 10, 2025", excerpt: "Optimize your Google Business Profile and local citations to attract nearby customers.", image: "https://placehold.co/600x400/1e3c72/white?text=Local+SEO", readTime: "6 min read" },
    { id: 8, title: "ChatGPT for Marketers: Practical Use Cases", category: "ai", date: "April 5, 2025", excerpt: "How to leverage ChatGPT for content ideation, email marketing, and customer support.", image: "https://placehold.co/600x400/0f2c44/white?text=ChatGPT+Marketing", readTime: "5 min read" }
];

function getCategoryDisplay(cat) { const map = { amazon: "📦 Amazon Sales", webdesign: "🌐 Web Design", seo: "🔍 SEO Tips", ai: "🤖 AI Marketing" }; return map[cat] || cat; }

function renderBlogPosts(category) {
    const grid = document.getElementById('blogGrid');
    const filtered = category === 'all' ? blogPosts : blogPosts.filter(post => post.category === category);
    if (filtered.length === 0) { grid.innerHTML = `<div class="no-results"><i class="fas fa-newspaper icon-empty-state"></i><h3>No posts found</h3></div>`; return; }
    grid.innerHTML = filtered.map(post => `<div class="blog-card"><img src="${post.image}" alt="${post.title}" class="blog-img"><div class="blog-content"><div class="blog-meta"><span class="blog-category">${getCategoryDisplay(post.category)}</span><span class="blog-date"><i class="far fa-calendar-alt"></i> ${post.date}</span><span><i class="far fa-clock"></i> ${post.readTime}</span></div><h3 class="blog-title">${post.title}</h3><p class="blog-excerpt">${post.excerpt}</p><a href="#" class="read-more" data-post-title="${post.title}">Read Full Article <i class="fas fa-arrow-right"></i></a></div></div>`).join('');
    document.querySelectorAll('.read-more').forEach(link => { link.addEventListener('click', (e) => { e.preventDefault(); alert(`📖 "${link.getAttribute('data-post-title')}"\n\nFull article preview. For complete insights, contact our team.`); }); });
}

const categoryBtns = document.querySelectorAll('.category-btn');
categoryBtns.forEach(btn => { btn.addEventListener('click', () => { const category = btn.getAttribute('data-category'); categoryBtns.forEach(b => b.classList.remove('active')); btn.classList.add('active'); renderBlogPosts(category); }); });
renderBlogPosts('all');

document.getElementById('subscribeBtn')?.addEventListener('click', () => { const email = document.getElementById('newsletterEmail').value.trim(); if(email && email.includes('@')) { alert(`✅ Subscribed! You'll receive updates at ${email}`); document.getElementById('newsletterEmail').value = ''; } else alert('Please enter a valid email.'); });

document.getElementById('quoteBtn')?.addEventListener('click', (e) => { e.preventDefault(); alert("📧 Get a Quote: Share your requirements at info@yourcompany.com."); });
